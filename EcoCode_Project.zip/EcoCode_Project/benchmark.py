import streamlit as st
import subprocess
import time
import psutil
import pandas as pd
import os
import glob

# --- CONFIG ---
TEST_SIZE = "40000" 

st.set_page_config(page_title="EcoCode AI", page_icon="🔋", layout="wide")

st.title("🔋 EcoCode AI: Real Battery Discharge Test")

# --- CHARGER CHECK ---
battery = psutil.sensors_battery()
col_msg, col_btn = st.columns([3, 1])
with col_btn:
    if st.button("🔄 Refresh Battery Status"):
        st.rerun()

with col_msg:
    if battery.power_plugged:
        st.error("⚠️ CHARGER DETECTED! Unplug your laptop for the real test.")
    else:
        st.success(f"✅ Running on Battery Power ({battery.percent}%)")

# --- SIDEBAR: FILE SELECTION ---
st.sidebar.header("⚙️ Experiment Setup")

cpp_files = glob.glob("*.cpp")
if not cpp_files:
    cpp_files = ["inefficient.cpp", "efficient.cpp"]

# Dropdowns (Efficient First)
good_file_cpp = st.sidebar.selectbox("Select Efficient Code (Runs 1st):", cpp_files, index=min(1, len(cpp_files)-1))
bad_file_cpp = st.sidebar.selectbox("Select Inefficient Code (Runs 2nd):", cpp_files, index=0)

# --- COMPILE FUNCTION ---
def compile_code(cpp_file):
    exe_name = cpp_file.replace(".cpp", "")
    if os.name == 'nt':
        exe_name += ".exe"
    compile_cmd = f"g++ {cpp_file} -o {exe_name}"
    os.system(compile_cmd)
    return exe_name

# --- ENGINE ---
def run_stress_test(executable, chart_slot, status_slot):
    start_batt = psutil.sensors_battery().percent
    start_time = time.time()
    
    cpu_data = []
    chart = chart_slot.line_chart([])
    
    # Run for 45 seconds
    while (time.time() - start_time) < 45:
        process = subprocess.Popen([f"./{executable}" if os.name != 'nt' else executable, TEST_SIZE])
        
        while process.poll() is None:
            current_cpu = psutil.cpu_percent(interval=0.1)
            current_time = round(time.time() - start_time, 1)
            
            new_row = pd.DataFrame({"CPU Load (%)": [current_cpu]}, index=[current_time])
            chart.add_rows(new_row)
            cpu_data.append(current_cpu)
            
            if (time.time() - start_time) > 45:
                process.terminate()
                break
        
        status_slot.text(f"Testing... {int(time.time() - start_time)}s / 45s")

    end_batt = psutil.sensors_battery().percent
    drop = start_batt - end_batt
    avg_load = sum(cpu_data) / len(cpu_data) if cpu_data else 0
    return drop, avg_load

# --- MAIN RUN BUTTON ---
if st.button("🚀 Start Live Test"):
    
    with st.spinner(f"Compiling..."):
        good_exe = compile_code(good_file_cpp)
        bad_exe = compile_code(bad_file_cpp)

    col1, col2 = st.columns(2)

    # --- LEFT: EFFICIENT CODE ---
    with col1:
        st.subheader(f"🌱 {good_file_cpp}")
        status_good = st.empty()
        chart_good = st.empty()
        drop_good, stress_good = run_stress_test(good_exe, chart_good, status_good)
        status_good.success(f"Test Complete. Stress Score: {int(stress_good)}")

    # --- RIGHT: INEFFICIENT CODE ---
    with col2:
        st.subheader(f"🔥 {bad_file_cpp}")
        status_bad = st.empty()
        chart_bad = st.empty()
        drop_bad, stress_bad = run_stress_test(bad_exe, chart_bad, status_bad)
        status_bad.error(f"Test Complete. Stress Score: {int(stress_bad)}")

    # --- RESULTS & RECOMMENDATION ---
    st.markdown("---")
    st.subheader("📊 AI Analysis Report")
    
    c1, c2, c3 = st.columns(3)
    c1.metric("Efficient Battery Drop", f"{drop_good}%", f"Avg CPU Load: {int(stress_good)}%")
    c2.metric("Inefficient Battery Drop", f"{drop_bad}%", f"Avg CPU Load: {int(stress_bad)}%")
    
    # Calculate Percentage Improvement
    if stress_bad > 0:
        improvement = ((stress_bad - stress_good) / stress_bad) * 100
    else:
        improvement = 0

    c3.metric("Efficiency Gain", f"{int(improvement)}% Better", "Less CPU Heat")

    # --- THE RECOMMENDATION BOX ---
    st.write("---")
    if stress_good < stress_bad:
        st.success(f"""
        ### ✅ AI Recommendation: Deploy '{good_file_cpp}'
        **Reasoning:** The analysis detected that '{bad_file_cpp}' consumes **{int(improvement)}% more CPU resources**, 
        which will lead to faster battery drainage and device overheating.
        
        **Action:** Replace the inefficient sorting logic with the optimized algorithm found in '{good_file_cpp}'.
        """)
        st.balloons()
    else:
        st.warning(f"""
        ### ⚠️ Inconclusive Result
        Both algorithms performed similarly. This might be due to the dataset size ({TEST_SIZE}) being too small 
        for the current hardware to show a difference. Try increasing the test size in the code.
        """)