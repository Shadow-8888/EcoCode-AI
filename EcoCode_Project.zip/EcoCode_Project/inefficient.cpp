#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>

int main(int argc, char* argv[]) {
    long long int a=999999999999999999;
    long long int sum=0;
    for(int i=0; i<a; i++) sum+=i;
    return 0;
}